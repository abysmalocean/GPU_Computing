make clean
make
./matrixmul
